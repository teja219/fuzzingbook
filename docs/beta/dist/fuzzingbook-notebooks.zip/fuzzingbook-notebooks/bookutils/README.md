This Python package holds various utilities for notebooks, 
in particular functionality such that notebooks can import each other.
